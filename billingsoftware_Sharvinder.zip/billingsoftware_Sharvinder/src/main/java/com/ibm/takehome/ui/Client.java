package com.ibm.takehome.ui;

import java.util.ArrayList;
import java.util.Scanner;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ibm.takehome.bean.Product;
import com.ibm.takehome.dao.IProductDAO;
import com.ibm.takehome.dao.ProductDAO;
import com.ibm.takehome.service.IProductService;
import com.ibm.takehome.service.ProductService;

public class Client {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);

		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("appContext.xml");
		IProductService services = context.getBean("productService", ProductService.class);
		
		
		mainScreen();
		System.out.println("Enter any one of the above choices:");
		int userChoice = sc.nextInt(); 
		switch(userChoice) {
		case 1:
			try {
				System.out.print("Enter the product code:");
				int productCode = sc.nextInt();
				
				System.out.print("Enter the quantity:");
				int quantityOfProduct = sc.nextInt();
				ArrayList<Product> product =(ArrayList<Product>) services.getProductDetails(productCode,quantityOfProduct) ;
				System.out.println(product);
				break;
			}
				catch(Exception e) {
					e.printStackTrace();
					break;}
			
		case 2: System.exit(0);
		
		default: System.out.println("Invalid choice. Please try again!");
				
		}
		main(null);
	}

	private static void mainScreen() {
		System.out.println("\t\t\t Welcome to Billing Software Application");	
		System.out.println("1) Generate Bill by entering Product code and quantity");
		System.out.println("2) Exit");
	}
	
	
}

		

	