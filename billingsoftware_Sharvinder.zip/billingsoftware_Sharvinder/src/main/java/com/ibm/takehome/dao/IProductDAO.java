package com.ibm.takehome.dao;

public interface IProductDAO {

	Object getProductDetails(int productCode);

}
