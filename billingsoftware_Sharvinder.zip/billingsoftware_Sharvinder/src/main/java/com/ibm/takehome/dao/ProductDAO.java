package com.ibm.takehome.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.ibm.takehome.bean.Product;

@Repository
public class ProductDAO {

	DataSource dataSource;

	NamedParameterJdbcTemplate namedTemplate;

	public DataSource getDataSource() {
		return dataSource;
	}

	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		namedTemplate = new NamedParameterJdbcTemplate(dataSource);
	}

	class UserMapper implements RowMapper<Product> {

		public Product mapRow(ResultSet rs, int rowNum) throws SQLException {
			Product user = new Product();

			user.setProductCode(rs.getInt("productCode"));
			user.setProductName(rs.getString("productName"));
			user.setProductCategory(rs.getString("productCategory"));
			user.setProductPrice(rs.getInt("productPrice"));

			return user;
		}
	}

	public ArrayList<Product> getProductDetails(int productCode) {
		String qry = "select * from products where productCode='" + productCode + "'";

		return (ArrayList<Product>) namedTemplate.query(qry, new UserMapper());

	}

}