package com.ibm.takehome.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Spliterator;
import java.util.function.Consumer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

//import com.capgemini.takehome.dao.IProductDAO;
import com.ibm.takehome.bean.Product;
import com.ibm.takehome.dao.IProductDAO;
import com.ibm.takehome.dao.ProductDAO;
import com.ibm.takehome.exceptions.InvalidQuantityException;
import com.ibm.takehome.exceptions.ProductNotFoundException;

@Service
public class ProductService implements IProductService {

	@Autowired
	ProductDAO productDao;
	Product prod = new Product();
	int price;

	public ArrayList<Product> getProductDetails(int productCode, final int quantityOfProduct)
			throws InvalidQuantityException, ProductNotFoundException {
		if (productDao.getProductDetails(productCode).isEmpty()) {
			throw new ProductNotFoundException("Sorry ! The Product Code <<" + productCode + ">> is not available");
		}

		else {
			if (quantityOfProduct > 0) {
				ArrayList<Product> product = productDao.getProductDetails(productCode);
				prod.setProductQuantity(quantityOfProduct);
				Spliterator<Product> split = product.spliterator();
				split.forEachRemaining(new Consumer<Product>() {
					public void accept(Product n) {
						n.setProductQuantity(quantityOfProduct);
						n.setProductLineTotal(calculateLineTotal(n.getProductPrice()));	
					}
				});
				
				return product;
			}

			else
				throw new InvalidQuantityException("Please Enter a valid Quantity");
		}
	}

	private int calculateLineTotal(int price) {
		return price * prod.getProductQuantity() ;

	}
}