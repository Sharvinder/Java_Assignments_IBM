package com.ibm.takehome.service;

import java.util.ArrayList;
import java.util.List;

import com.ibm.takehome.bean.Product;
import com.ibm.takehome.exceptions.InvalidQuantityException;
import com.ibm.takehome.exceptions.ProductNotFoundException;

public interface IProductService {

	ArrayList<Product> getProductDetails(int productCode,int quantityOfProduct)throws InvalidQuantityException,ProductNotFoundException;


}

