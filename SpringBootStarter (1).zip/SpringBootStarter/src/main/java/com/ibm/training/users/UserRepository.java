package com.ibm.training.users;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Repository;

@Repository
public class UserRepository {


	List<User> listOfUsers = new ArrayList<>(
				Arrays.asList(
					new User(1, "Aditya", "Delhi"),
					new User(23, "Mohan", "Noida"),
					new User(341, "Ram", "Agra")
					));
	
	List<User> getAllUsers() {
		return listOfUsers;
	}

	public User getUser(int id) {
		return listOfUsers.stream().filter(ref -> ref.getId().equals(id)).findFirst().get();
	}

	public void addUser(User user) {
		listOfUsers.add(user);
		
	}

	public void updateUser(User user, int id) {
		for(User curUser: listOfUsers) {
			if(curUser.getId().equals(id)) {
				listOfUsers.set(listOfUsers.indexOf(curUser), user);
			}
		}
		
	}

	public void deleteUser(int id) {
		User temp = null;
		for(User curUser: listOfUsers) {
			if(curUser.getId().equals(id)) {
				temp = curUser;
				break;
			}
		}
		listOfUsers.remove(temp);
		
	}
	
}
