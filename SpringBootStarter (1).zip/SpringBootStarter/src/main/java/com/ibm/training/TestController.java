package com.ibm.training;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

//Make this class as a Rest Controller : we can expose a bunch of rest end points
@RestController
@RequestMapping("/pro")
public class TestController {
	
	@Autowired
	TestService service;
	
	@RequestMapping("/data")
	String demoEndPoint() {
		return service.getData();
	}
	
	@RequestMapping("/test")
	String demoEndPoint2() {
		return "This is the second rest end point, just for demonstration...";
	}

}