package com.ibm.training;

import org.springframework.stereotype.Repository;

@Repository
public class TestDao {
	
	String getDataFromDB() {
		return "This is coming from the db...";
	}
}
