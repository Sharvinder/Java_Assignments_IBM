package com.ibm.training.users;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {
	
	@Autowired
	UserRepository repo;

	public List<User> getAllUsers() {
		return repo.getAllUsers();
	}

	public User getUser(int id) {
		
		return repo.getUser(id);
	}

	public void addUser(User user) {
		repo.addUser(user);
		
	}

	public void updateUser(User user, int id) {
		repo.updateUser(user, id);
		
	}

	public void deleteUser(int id) {
		repo.deleteUser(id);
		
	}

}
