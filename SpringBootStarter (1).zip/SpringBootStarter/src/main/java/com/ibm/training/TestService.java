package com.ibm.training;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TestService {
	
	@Autowired
	TestDao dao;
	
	String getData() {
		return dao.getDataFromDB();
	}
}
